Third party licenses by different vendors:
=========================================

Apache Struts : Apache License, Version 2.0 -  The Apache Software Foundation

H2 : Mozilla Public License, Version 2.0 - H2 Group

JSch : BSD License - Atsuhiko Yamanaka, JCraft,Inc

Google-Gson : Apache License, Version 2.0 - Google, Inc.

Apache Commons FileUpload : Apache License, Version 2.0 -  The Apache Software Foundation

Apache Commons Codec : Apache License, Version 2.0 -  The Apache Software Foundation

Apache Commons DBCP : Apache License, Version 2.0 -  The Apache Software Foundation

Apache Commons Configuration : Apache License, Version 2.0 -  The Apache Software Foundation

ZXing : Apache License, Version 2.0 -  ZXing Authors

Bootstrap : MIT License - Twitter, Inc.

jQuery : MIT License - jQuery Foundation, Inc.

jQueryUI : MIT License - jQuery Foundation, Inc.

jquery.floatThead : MIT License - Misha Koryak

term.js : MIT License - Christopher Jeffrey
